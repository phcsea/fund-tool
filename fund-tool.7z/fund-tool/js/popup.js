/**
 * 监听消息
 * chrome.runtime.sendMessage({},function(response){});
 */
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.action == "sendNotify") {
        setTimeout(function() {
            _list();
        }, 8000);
        sendResponse({ status: "refresh_finish" });
    }
});

var compare = function(property) {
    return function(a, b) {
        var value1 = a[property];
        var value2 = b[property];

        return value1 - value2;
    }
}

var _list = function() {
    var $_GET = {};
    document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function() {
        function decode(s) {
            return decodeURIComponent(s.split("+").join(" "));
        }
        $_GET[decode(arguments[1])] = decode(arguments[2]);
    });

    var preview;
    try {
        preview = jQuery.parseJSON(localStorage.getItem("preview"))
    } catch (e) {
        preview = JSON.parse("{}");
    }

    var preview_storage = $_GET["preview"] == "true" ? preview : localStorage;
    var storage_key = preview_storage == null ? {} : Object.keys(preview_storage).sort();

    $(".fund_list").remove();

    var total = 0;
    var total_jingzhi = 0;
    var gs_total_jingzhi = 0;
    var append_str = "";
    for (var i in storage_key) {
        if (isNumeric(storage_key[i])) {
            var content = $_GET["preview"] == "true" ? JSON.stringify(preview_storage[storage_key[i]]) : localStorage.getItem(storage_key[i]);
            if (content != "") {
                var json_str = JSON.parse(content);

                var light = "";
                if (parseFloat(json_str.now) >= parseFloat(json_str.sell)) {
                    light = "am-danger";
                } else if (parseFloat(json_str.adding) >= parseFloat(json_str.now)) {
                    light = "am-success";
                }
                //由于新版没有这个变量，需要手动判断是否为空
                var fene = isBlank(json_str.fene) ? "" : parseFloat(json_str.fene);
                var jingzhi = isBlank(json_str.jingzhi) ? "" : parseFloat(json_str.jingzhi);
                var jingzhi_time = isBlank(json_str.jingzhi_time) ? "" : "(" + json_str.jingzhi_time + ")";
                var newest_jingzhi_time = isBlank(json_str.gztime) ? "" : "(" + moment(json_str.gztime).format("H:mm") + ")";
                var offset = isBlank(json_str.offset) ? "" : "(" + json_str.offset + ")";

                var yesterdayrate = isBlank(json_str.yesterdayrate) ? "" : json_str.yesterdayrate;
                var two_yesterdayrate = isBlank(json_str.two_yesterdayrate) ? "" : json_str.two_yesterdayrate;
                var three_yesterdayrate = isBlank(json_str.three_yesterdayrate) ? "" : json_str.three_yesterdayrate;

                var funddate = isBlank(json_str.funddate) ? "" : "(" + json_str.funddate + ")";
                var size = isBlank(json_str.size) ? "" : "(" + json_str.size + ")";
                var fund_type = isBlank(json_str.fund_type) ? "" : "(" + json_str.fund_type + ")";

                var gszzl = 0;
                var temp_yesterdayrate = isBlank(json_str.yesterdayrate) ? 0 : json_str.yesterdayrate.replace("%", "");
                var temp_two_yesterdayrate = isBlank(json_str.two_yesterdayrate) ? 0 : json_str.two_yesterdayrate.replace("%", "");
                var temp_three_yesterdayrate = isBlank(json_str.three_yesterdayrate) ? 0 : json_str.three_yesterdayrate.replace("%", "");

                if (temp_three_yesterdayrate < 0) {
                    gszzl += (1 * temp_three_yesterdayrate) + (1 * temp_two_yesterdayrate);
                } else {
                    gszzl += 1 * temp_two_yesterdayrate;
                }
                if (temp_two_yesterdayrate < 0) {
                    gszzl += (1 * temp_two_yesterdayrate) + (1 * temp_yesterdayrate);
                } else {
                    gszzl += 1 * temp_yesterdayrate;
                }
                if (temp_yesterdayrate < 0) {
                    gszzl += (1 * temp_yesterdayrate) + (1 * json_str.gszzl);
                } else {
                    gszzl += 1 * json_str.gszzl;
                }

                //盈亏估算 = 持有份额 * (最新价格 - 单位净值)
                var yingkui = (fene == "" || isBlank(json_str.now)) ? "-" : (fene * (parseFloat(json_str.now) - parseFloat(jingzhi))).toFixed(2);
                if (isNumeric(yingkui)) {
                    total += parseFloat(yingkui);
                }

                //持有收益 = 持有份额 * (单位净值 - 成本价)
                var yingkui_jingzhi = (fene == "" || jingzhi == "") ? "-" : (fene * (parseFloat(jingzhi) - json_str.buy)).toFixed(2);
                if (isNumeric(yingkui_jingzhi)) {
                    total_jingzhi += parseFloat(yingkui_jingzhi);
                }

                //持仓市值 = 持有份额 * 单位净值
                var chicang_jingzhi = (fene == "" || jingzhi == "") ? "0" : (fene * parseFloat(jingzhi)).toFixed(2);

                //估算持有收益 = 持有收益 + 总盈亏估算
                gs_total_jingzhi = total_jingzhi + total;

                var old_rate = (fene == "" || jingzhi == "") ? "-" : (((yingkui_jingzhi / ((fene * parseFloat(json_str.buy)).toFixed(2))) * 100).toFixed(2));
                var valuate_rate = (fene == "" || jingzhi == "") ? "-" : ((((parseFloat(json_str.now) / parseFloat(json_str.buy)) - 1) * 100).toFixed(2));

                var my_most_valuate_rate = 8;
                var my_most_old_rate = 5;

                var is_sell_most_rate = (json_str.gszzl * 1 + temp_yesterdayrate * 1 + temp_two_yesterdayrate * 1 + temp_three_yesterdayrate * 1) > 3.5 ? false : true;

                var _good_fund_type = $("#good_fund_type").val();
                if (_good_fund_type == 1) {
                    var good_funds = [
                        "160716",
                        "000311",
                        "163407",
                        "160219",
                        "162711",
                        "001051",
                        "519697",
                        "040025",
                        "163402",
                        "519069",
                        "001938",
                        "001178",
                        "000083",
                        "000878",
                        "001133",
                        "001264",
                        "005918",
                        "110003",
                        "110011",
                        "110022",
                        "160222",
                        "160625",
                        "161227",
                        "162605",
                        "217016",
                        "519100",
                        "320010",
                        "481012",
                        "530015",
                        "720001",
                    ];
                    if ($.inArray(json_str.code, good_funds) == -1) {
                        if ((gszzl > -2.5 || old_rate < my_most_old_rate) && valuate_rate < my_most_valuate_rate && is_sell_most_rate) {
                            continue;
                        }
                    }
                }
                if (valuate_rate < my_most_valuate_rate || chicang_jingzhi * 1 <= 0) {
                    if ((gszzl > -2 && valuate_rate < my_most_valuate_rate && is_sell_most_rate)) {
                        // continue;
                    }
                    if ((chicang_jingzhi * 1 < 100 && is_sell_most_rate)) {
                        // continue;
                    }
                    if (chicang_jingzhi * 1 == 0 && !is_sell_most_rate) {
                        // continue;
                    }
                }
                if (chicang_jingzhi * 1 < 300) {
                    // continue;
                }

                var notice = isBlank(json_str.notice) ? "" : parseInt(json_str.notice);
                var notice_icon = "";
                switch (notice) {
                    case 2:
                        notice_icon = "am-icon-pause";
                        break;
                    case 4:
                        notice_icon = "am-icon-line-chart";
                        break;
                    case 6:
                        notice_icon = "am-icon-sort-amount-desc";
                        break;
                    default:
                        notice_icon = "";
                }

                append_str +=
                    '<tr class="fund_list ' + json_str.code + ' ' + light + ' ">' +
                    '   <td class="am-text-middle am-show-lg-only">' +
                    '       <label class="am-checkbox-inline">' +
                    '           <input name="notice_checkbox" type="checkbox" value="' + json_str.code + '"> ' + json_str.name +
                    '               <i class="' + notice_icon + '"></i> ' +
                    '       </label>' +
                    '       <span class="am-text-xs am-block">' + funddate + '~' + size + '<span class="am-text-xs am-block">' + fund_type + '</span></span>' +
                    '   </td>' +
                    '   <td class="am-text-middle" title="' + json_str.name + '">' + json_str.code +
                    '       <i class="view-fund am-icon-external-link" data="' + json_str.code + '"></i>' +
                    '       <span class="am-text-xs am-block">' + size + '</span>' +
                    '   </td>' +
                    '   <td class="am-text-middle">' +
                    '       <input type="text" class="am-text-center input-size" value="' + json_str.buy + '"  placeholder-text="购入成本价格"  name="buy" />' +
                    '   </td>' +
                    '   <td class="am-text-middle">' +
                    '       <input type="text" class="am-text-center input-size" value="' + json_str.adding + '"  placeholder-text="补仓价格提醒" name="adding" />' +
                    '   </td>' +
                    '   <td class="am-text-middle">' +
                    '       <input type="text" class="am-text-center input-size" value="' + json_str.sell + '"  placeholder-text="卖出价格提醒" name="sell" />' +
                    '   </td>' +
                    '   <td class="am-text-middle">' +
                    '       <input type="text" class="am-text-center input-large-size" value="' + fene + '" placeholder-text="持有份额" name="fene" />' +
                    '   </td>';
                if (old_rate >= my_most_old_rate) {
                    append_str += '   <td class="am-text-middle jz_list" data-code="' + json_str.code + '">' + jingzhi + '<span class="am-text-xs am-block">' + jingzhi_time + '</span><span class="am-text-xs am-block red-deep">(' + old_rate + '%)</span></td>';
                } else {
                    append_str += '   <td class="am-text-middle jz_list" data-code="' + json_str.code + '">' + jingzhi + '<span class="am-text-xs am-block">' + jingzhi_time + '</span><span class="am-text-xs am-block">(' + old_rate + '%)</span></td>';
                }
                append_str += '   <td class="am-text-middle" title="最后更新时间: ' + json_str.gztime + '">' + json_str.now + '<span class="am-text-xs am-block">' + newest_jingzhi_time + '</span></td>';
                if (valuate_rate >= my_most_valuate_rate) {
                    append_str += '   <td class="am-text-middle">' + yingkui + '<span class="am-text-xs am-block">(' + chicang_jingzhi + ')</span><span class="am-text-xs am-block red-deep">(' + valuate_rate + '%)</span></td>';
                } else {
                    append_str += '   <td class="am-text-middle">' + yingkui + '<span class="am-text-xs am-block">(' + chicang_jingzhi + ')</span><span class="am-text-xs am-block">(' + valuate_rate + '%)</span></td>';
                }

                if (gszzl < -6) {
                    append_str += '   <td class="am-text-middle estimatedchart" data-code="' + json_str.code + '"><span class="am-text-xs am-block">(' + three_yesterdayrate + '|' + two_yesterdayrate + '|' + yesterdayrate + ')</span><span class="am-text-xs am-block red-deep">' + json_str.gszzl + '%</span><span class="am-text-xs am-block">' + offset + '</span></td>';
                } else if (-6 <= gszzl && gszzl < -3) {
                    append_str += '   <td class="am-text-middle estimatedchart" data-code="' + json_str.code + '"><span class="am-text-xs am-block">(' + three_yesterdayrate + '|' + two_yesterdayrate + '|' + yesterdayrate + ')</span><span class="am-text-xs am-block red-tiny">' + json_str.gszzl + '%</span><span class="am-text-xs am-block">' + offset + '</span></td>';
                } else if (-3 <= gszzl && gszzl < -2.1) {
                    append_str += '   <td class="am-text-middle estimatedchart" data-code="' + json_str.code + '"><span class="am-text-xs am-block">(' + three_yesterdayrate + '|' + two_yesterdayrate + '|' + yesterdayrate + ')</span><span class="am-text-xs am-block red-light">' + json_str.gszzl + '%</span><span class="am-text-xs am-block">' + offset + '</span></td>';
                } else {
                    append_str += '   <td class="am-text-middle estimatedchart" data-code="' + json_str.code + '"><span class="am-text-xs am-block">(' + three_yesterdayrate + '|' + two_yesterdayrate + '|' + yesterdayrate + ')</span><span class="am-text-xs am-block">' + json_str.gszzl + '%</span><span class="am-text-xs am-block">' + offset + '</span></td>';
                }

                append_str +=
                    '   <td class="am-text-middle action-btns">' +
                    '       <div class="am-inline-block">' +
                    '           <span class="am-btn am-btn-xs am-btn-primary edit" data="' + json_str.code + '">修改</span>' +
                    '           <span class="am-btn am-btn-xs am-btn-danger delete" data="' + json_str.code + '">删除</span>' +
                    '       </div>' +
                    '   </td>' +
                    '</tr>';
            }
        }
    }
    $("#head").after(append_str);

    $("table td.total").html(total.toFixed(2) + '<span class="am-text-xs am-block">( ' + gs_total_jingzhi.toFixed(2) + ' )</span>');

    $("body").on("click", ".estimatedchart", function() {
        dialog({
            quickClose: true,
            height: 281,
            width: 451,
            id: "id-estimatedchart",
            url: "http://j4.dfcfw.com/charts/pic6/" + $(this).data("code") + ".png?v=" + Math.random(),
        }).show();
    });

    $("body").on("click", ".jz_list", function() {
        dialog({
            quickClose: true,
            height: 270,
            width: 770,
            id: "id-jz_list",
            url: "http://j3.dfcfw.com/images/JJJZ1/" + $(this).data("code") + ".png",
        }).show();
    });

    if ($_GET["preview"] == "true") {
        $("input").attr("disabled", "disabled")
        $(".am-btn").remove();
        var table_str = $("table").clone();
        $(".am-padding").html(table_str);
        $("table").before("<p>备份ID: <strong>" + $_GET["restore"] + "</strong></p>");
    }
}

$(function() {
    /**
     * 刷新列表和获取最新价格
     */
    $(".refresh").on("click", function() {
        var d = dialog({
            title: "刷新中...",
            id: "refresh_fund"
        }).width(85).showModal();
        refreshFund(true);
        setTimeout(function() {
            _list();
            d.close().remove();
        }, 2000);
    });

    /**
     * 帮助文档
     */
    $(".document").on("click", function() {
        chrome.tabs.create({ url: "https://www.pescms.com/d/v/32/84.html" });
    });

    /**
     * 全屏按钮
     */
    $(".popup").on("click", function() {
        chrome.tabs.create({ url: "popup.html" });
    });

    /**
     * 备份
     */
    $(".backup").on("click", function() {
        chrome.tabs.create({ url: "backup.html" });
    });

    /**
     * 数据来源
     */
    $(".fund-source").on("click", function() {
        chrome.tabs.create({ url: "http://fund.eastmoney.com/" });
    });

    /**
     * 清空图表下方的数字提醒
     */
    chrome.browserAction.setBadgeText({ text: "" });

    /**
     * 更改通知设置
     */
    $("body").on("click", ".update-notice", function() {
        var check_update = false;
        var notice_type = $("select[name=notice_type]").val();
        if (notice_type == "0") {
            alert("请选择要更改通知的设置类型");
            return false;
        }
        $("input[name='notice_checkbox']:checked").each(function() {
            var code = $(this).val();
            var fund = JSON.parse(localStorage.getItem(code));
            if (fund) {
                fund["notice"] = notice_type
                localStorage.setItem(code, JSON.stringify(fund));
                check_update = true;
            }
        });

        if (check_update) {
            var d = dialog({
                title: "Tips",
                content: "更改设置完成!"
            });
            d.showModal();
            setTimeout(function() {
                d.close().remove();
                $(".checkbox-all").removeAttr("checked")
                _list();
            }, 1500);
        }
    });

    /**
     * 标准严选基金
     */
    $("#good_fund_type").on("change", function() {
        _list();
    });

    /**
     * 新增基金
     */
    $("#add .am-btn-success.add").on("click", function() {
        var input_content = $("#add input").serializeArray();
        var item = {};
        for (var i in input_content) {
            var value = input_content[i]["value"];
            var msg = $("input[name=" + input_content[i]["name"] + "]").attr("placeholder");
            if (isBlank(value)) {
                _alert("请输入" + msg);
                return false;
            }
            if (isNumeric(value) == false) {
                _alert(msg + "仅限输入数字");
                return false;
            }
            item[input_content[i]["name"]] = input_content[i]["value"]
        }

        localStorage.setItem(input_content[0]["value"], JSON.stringify(item));
        $("#add input").val("");
        _alert("新增基金成功");
        _list();
    });

    /**
     * 修改基金信息
     */
    $("body").on("click", ".am-btn-primary.edit", function() {
        var code = $(this).attr("data");
        var inputDom = $(this).closest("tr").find("input");
        var input_content = inputDom.serializeArray();
        var fund = JSON.parse(localStorage.getItem(code));
        for (var i in input_content) {
            var value = input_content[i]["value"];
            var msg = $("input[name=" + input_content[i]["name"] + "]").attr("placeholder-text");
            if (isBlank(value)) {
                _alert("请输入" + msg);
                return false;
            }
            if (isNumeric(value) == false) {
                _alert(msg + "仅限输入数字");
                return false;
            }
            fund[input_content[i]["name"]] = input_content[i]["value"]
        }
        localStorage.setItem(code, JSON.stringify(fund));
        _alert("修改 " + code + " 基金成功");
        inputDom.addClass("am-text-primary");
        setTimeout(function() {
            _list();
        }, 2500);
    });

    /**
     * 删除基金
     */
    $("body").on("click", ".am-btn-danger.delete", function() {
        var id = $(this).attr("data");
        if (confirm("您确定要删除 " + id + " 基金吗？")) {
            localStorage.removeItem(id);
            _list();
        }
    });

    /**
     * 点击跳转对应的天天基金的详细页
     */
    $("body").on("click", ".view-fund", function() {
        var code = $(this).attr("data");
        chrome.tabs.create({ url: "http://fund.eastmoney.com/" + code + ".html" });
    });

    /**
     * 全选OR取消全选
     */
    $(".checkbox-all").on("click", function() {
        if ($(this).prop("checked")) {
            $("input[name='notice_checkbox']").attr("checked", "checked")
        } else {
            $("input[name='notice_checkbox']").removeAttr("checked")
        }
    });

    refreshFund(true);
    setTimeout(function() {
        _list();
    }, 500);
});