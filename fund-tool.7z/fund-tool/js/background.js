/**
 * 消息提醒
 */
var notifications = function () {
    var saveNotice = {}
    var date = moment().format("YYYY-MM-DD");
    var time = moment().format("H:mm").split(":");

    //非工作日不提醒 PS:法定假期无法判定呀。这个需要人工介入，就不管理了
    if (moment().format("d") == 0 || moment().format("d") == 6) {
        return false;
    }

    if (parseInt(time[0]) != 14 || parseInt(time[1]) < 30) {
        return false;
    }
    var getNoticeLocalStorage = JSON.parse(localStorage.getItem("saveNotice"));

    var badgeNumber = 0;

    for (var i in localStorage) {
        if (isNumeric(i)) {
            var content = localStorage.getItem(i);
            if (content != "") {
                var json_str = JSON.parse(content);

                var msg = json_str.name + " " + i;
                var icon = "";

                var notice = isBlank(json_str.notice)? "": parseInt(json_str.notice);

                if (parseFloat(json_str.now) >= parseFloat(json_str.sell) && notice != 2 && notice != 4) {
                    msg += " 基金涨幅已达到可卖出价格，请及时处理";
                    icon = "sell.png";
                    saveNotice[i] = (getNoticeLocalStorage == null || !getNoticeLocalStorage[date] || !getNoticeLocalStorage[date][i]) ? 11 : getNoticeLocalStorage[date][i] + 1;
                } else if (parseFloat(json_str.adding) >= parseFloat(json_str.now) && notice != 2 && notice != 6) {
                    msg += " 基金跌幅已达到补仓价格，请及时处理";
                    icon = "adding.png";
                    saveNotice[i] = (getNoticeLocalStorage == null || !getNoticeLocalStorage[date] || !getNoticeLocalStorage[date][i]) ? 11 : getNoticeLocalStorage[date][i] + 1;
                } else {
                    continue;
                }

                if (getNoticeLocalStorage == null || !getNoticeLocalStorage[date] || getNoticeLocalStorage[date][i] % 5 == 0) {
                    chrome.notifications.create(null, {
                            type: "basic",
                            iconUrl: "img/" + icon,
                            title: "基金定投提醒",
                            message: msg
                        });
                    badgeNumber++;
                }
            }
        }
    }

    //添加通知图标数字提醒
    if (badgeNumber > 0) {
        chrome.browserAction.setBadgeText({text: String(badgeNumber)});
        chrome.browserAction.setBadgeBackgroundColor({color: [255, 0, 0, 255]});
    }
    localStorage.setItem("saveNotice", JSON.stringify({[date]: saveNotice}));
}

/**
 * 当定时器到达时间时产生
 */
chrome.alarms.onAlarm.addListener(function(alarm) {
    if (alarm.name == "notifyAlarm") {
        notifications();
    } else if (alarm.name == "refreshAlarm") {
        var time = moment().format("H");
        if ((parseInt(time) < 8 || parseInt(time) > 15)) {
            return false;
        }
        refreshFund(false);
        chrome.runtime.sendMessage({
            action: "sendNotify"
        }, function (response) { });
    }
});

/**
 * 创建定时器
 */
chrome.alarms.create("refreshAlarm",{periodInMinutes: 2});
chrome.alarms.create("notifyAlarm",{periodInMinutes: 1});