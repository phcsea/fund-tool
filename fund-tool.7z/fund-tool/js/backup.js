/**
 * 还原数据
 * @param json 需要还原的数据
 * @returns {boolean}
 */
var restore_data = function (json) {
    try {
        for (var i in localStorage) {
            if (isNumeric(i)) {
                localStorage.removeItem(i);
            }
        }

        var json_content = JSON.parse(json)
        for (var i in json_content) {
            localStorage.setItem(i, JSON.stringify(json_content[i]));
        }

        alert("数据还原成功!");
        window.location.reload();
    } catch (error) {
        alert("备份数据存在异常,程序无法解包");
        return false;
    }
}

$(function () {
    /**
     * 在页面列出手动备份的JSON
     */
    var print_backup_json = function () {
        var backup = {};

        for (var i in localStorage) {
            if (isNumeric(i)) {
                var content = localStorage.getItem(i);
                if (content != "") {
                    backup[i] = JSON.parse(content);
                }
            }
        }
        backup = JSON.stringify(backup);
        $("#backup-data").html(backup);
        $("#hidden-backup-data").val(backup);
    }();

    /**
     * 点击“还原数据”按钮
     */
    $(".restore").on("click", function () {
        if (!confirm("确认要还原数据?已有数据将被覆写!")) {
            return false;
        }

        var content = $(".restore-content").val();
        if (isBlank(content)) {
            alert("请输入您要还原的备份数据");
            return false;
        }
        restore_data(content)
    });
    $("#copy-data").on("click", function () {
        var target=document.getElementById("hidden-backup-data");
        target.select();
        document.execCommand("Copy");
    });
});