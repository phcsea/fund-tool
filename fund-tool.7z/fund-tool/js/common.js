/**
 * 验证是否为数字
 * @param n
 * @returns {boolean}
 */
function isNumeric(n) {
    return !isNaN(parseFloat(n)) && isFinite(n);
}

/**
 * 用于判断空，Undefined String Array Object
 */
function isBlank(str) {
    if (Object.prototype.toString.call(str) === "[object Undefined]") { //空
        return true
    } else if (Object.prototype.toString.call(str) === "[object String]" || Object.prototype.toString.call(str) === "[object Array]") { //字条串或数组
        return str.length == 0 ? true : false
    } else if (Object.prototype.toString.call(str) === "[object Object]") {
        return JSON.stringify(str) == "{}" ? true : false
    } else {
        return true
    }
}

/**
 * 弹窗提醒
 * @param msg 提示信息
 * @private
 */
var _alert = function(msg) {
    var d = dialog({
        title: "Tips",
        content: msg,
        id: "_alert"
    });
    d.showModal();
    setTimeout(function() {
        d.close().remove();
    }, 1500);
}

/**
 * 基金实时信息
 */
var refreshFund = function(user) {
    var time = moment().format("H");
    if ((parseInt(time) < 8 || parseInt(time) > 15) && user == false) {
        // return false;
    }

    var xhr = [];
    for (var key in localStorage) {
        if (isNumeric(key)) {
            (function(key) {
                xhr[key] = new XMLHttpRequest();
                xhr[key].open("GET", "http://fundgz.1234567.com.cn/js/" + key + ".js?rt=" + Math.random(), true);
                xhr[key].onreadystatechange = function() {
                    if (xhr[key].readyState == 4) {
                        var result = xhr[key].responseText;
                        if (result) {
                            //将JSONP格式手动解析为JSON字符串
                            try {
                                var fund = JSON.parse(result.match(/[a-z]+\((.*)\)/)[1]);
                                if (fund) {
                                    //查找本地存储的基金数据
                                    var record = JSON.parse(localStorage.getItem(fund["fundcode"]))
                                    if (record) {
                                        //组装并更新对应基金的实时估算值
                                        record["name"] = fund["name"];
                                        record["now"] = fund["gsz"];
                                        record["gszzl"] = fund["gszzl"];
                                        record["gztime"] = fund["gztime"];
                                        record["jingzhi"] = fund["dwjz"];
                                        record["jingzhi_time"] = fund["jzrq"];
                                        record["offset"] = record["offset"];
                                        localStorage.setItem(fund["fundcode"], JSON.stringify(record));
                                    }
                                }
                            } catch (err) {}
                        }
                    }
                }
                xhr[key].send();
            })(key);
        }
    }
    setTimeout(function() {
        jingZhiOffset();
    }, 2000);
}

var jingZhiOffset = function() {
    var time = moment().format("H");
    if ((parseInt(time) > 13)) {
        // return false;
    }
    var xhr = [];
    for (var key in localStorage) {
        if (isNumeric(key)) {
            (function(key) {
                xhr[key] = new XMLHttpRequest();
                xhr[key].open("GET", "http://fund.eastmoney.com/" + key + ".html?rt=" + Math.random(), true);
                xhr[key].onreadystatechange = function() {
                    if (xhr[key].readyState == 4) {
                        var result = xhr[key].responseText;
                        if (result) {
                            var $result = $(result);
                            var fundcode = $result.find("div.merchandiseDetail .fundDetail-header .fundDetail-tit .ui-num").first().text();
                            var offset = $.trim($result.find("span.estimated_netWrth>span").text());

                            var yesterdayrate = $.trim($result.find("div.fundInfoItem div.dataOfFund dl.dataItem02 dd.dataNums span.ui-num").last().text());

                            var $_jingzhi_tr_tag = $result.find("#Div2 #Li1 .poptableWrap.singleStyleHeight01 table tbody tr");
                            var two_yesterdayrate = $.trim($_jingzhi_tr_tag.eq(2).find(".alignRight10").text());
                            var three_yesterdayrate = $.trim($_jingzhi_tr_tag.eq(3).find(".alignRight10").text());

                            var fund_type = $.trim($result.find("div.fundDetail-main div.fundInfoItem div.infoOfFund table tbody tr").first().find("td").eq(0).text());
                            var size = $.trim($result.find("div.fundDetail-main div.fundInfoItem div.infoOfFund table tbody tr").first().find("td").eq(1).text());
                            var funddate = $.trim($result.find("div.fundDetail-main div.fundInfoItem div.infoOfFund table tbody tr").eq(1).find("td").first().text());

                            if (!fund_type) {
                                fund_type = "";
                            }
                            if (!size) {
                                size = "";
                            }
                            if (!funddate) {
                                funddate = "";
                            }
                            fund_type = fund_type.replace("基金类型：", "");
                            size = size.replace("基金规模：", "");
                            size = size.replace(/\（[^\）]*\）/g, "");
                            funddate = funddate.replace("成 立 日：", "");

                            if (!offset) {
                                offset = "0%";
                            }
                            if (!yesterdayrate) {
                                yesterdayrate = "0%";
                            }
                            if (!two_yesterdayrate) {
                                two_yesterdayrate = "0%";
                            }
                            if (!three_yesterdayrate) {
                                three_yesterdayrate = "0%";
                            }
                            var record = JSON.parse(localStorage.getItem(fundcode))
                            if (record) {
                                record["offset"] = offset;
                                record["yesterdayrate"] = yesterdayrate;
                                record["two_yesterdayrate"] = two_yesterdayrate;
                                record["three_yesterdayrate"] = three_yesterdayrate;
                                record["size"] = size;
                                record["funddate"] = funddate;
                                record["fund_type"] = fund_type;
                                localStorage.setItem(fundcode, JSON.stringify(record));
                            }
                        }
                    }
                }
                xhr[key].send();
            })(key);
        }
    }
}

/**
 * 基金历史净值数据
 * 
 * http://fund.eastmoney.com/f10/F10DataApi.aspx?type=lsjz&code=110022&sdate=2018-02-22&edate=2018-03-02&per=20
 * type：类型，历史净值用lsjz表示
 * code：基金代码，六位数字
 * sdate：开始日期，格式是yyyy-mm-dd
 * edate：结束日期，格式是yyyy-mm-dd
 * per：一页显示多少条记录
 */
var refreshJingzhi = function(user) {
    var time = moment().format("H");
    if ((parseInt(time) > 9 && parseInt(time) < 19) && user == false) {
        // return false;
    }

    var xhr = [];
    for (var key in localStorage) {
        if (isNumeric(key)) {
            (function(key) {
                xhr[key] = new XMLHttpRequest();
                xhr[key].open("GET", "http://fund.eastmoney.com/f10/F10DataApi.aspx?type=lsjz&code=" + key + "&page=1&per=49&sdate=&edate=&rt=" + Math.random(), true);
                xhr[key].onreadystatechange = function() {
                    if (xhr[key].readyState == 4) {
                        var result = xhr[key].responseText;
                        if (result) {
                            var jsonObj = parseJsonObject(result);
                            historyJingzhi(key, jsonObj["pages"]);
                        }
                    }
                }
                xhr[key].send();
            })(key);
        }
    }
}

/**
 * 该基金的所有历史净值数据
 */
var historyJingzhi = function(code, pages) {
    var records = [];
    var xhr = [];
    for (var page = 1; page <= pages; page++) {
        (function(page) {
            xhr[page] = new XMLHttpRequest();
            xhr[page].open("GET", "http://fund.eastmoney.com/f10/F10DataApi.aspx?type=lsjz&code=" + code + "&page=" + page + "&per=49&sdate=&edate=&rt=" + Math.random(), true);
            xhr[page].onreadystatechange = function() {
                if (xhr[page].readyState == 4) {
                    var result = xhr[page].responseText;
                    if (result) {
                        //将JSONP格式手动解析为JSON字符串
                        try {
                            var result_match = result.match(/<tbody.*>.*?<\/tbody>/);
                            if (result_match) {
                                var old_records = {};
                                try {
                                    var old_records_json = JSON.parse(isBlank(localStorage.getItem("records")) ? "{}" : localStorage.getItem("records"));
                                    records = old_records_json[code];
                                    if (isBlank(records) || page == 1) {
                                        records = [];
                                    }
                                    var $trs = $(result_match[0]).find("tr");
                                    $.each($trs, function(index, item) {
                                        var item = {
                                            "date": $(this).find("td").first().html(),
                                            "value": $(this).find(".tor.bold").first().html(),
                                            "totalValue": $(this).find(".tor.bold").eq(1).html(),
                                            "rate": isBlank($(this).find(".tor.bold").last().html()) ? "0%" : $(this).find(".tor.bold").last().html(),
                                        };
                                        records.push(item);
                                    });
                                } catch (e) {}
                                old_records[code] = records;
                                localStorage.setItem("records", JSON.stringify(old_records));
                            }
                        } catch (err) {}
                    }
                }
            }
            xhr[page].send();
        })(page);
    }
}

var lastRecords = function() {
    var detailSortRecords = {};
    var tempSortRecords = {};
    var tempTypes = [];
    var types = ["oneWeek", "oneMonth", "threeMonth", "sixMonth", "oneYear", "twoYear", "threeYear", "thisYear", "allYear"];
    var fts = ["zzf", "1yzf", "3yzf", "6yzf", "1nzf", "2nzf", "3nzf", "jnzf", "lnzf"];
    // all  全部
    // gp   股票型
    // hh   混合型
    // zs   指数型

    // zq   债券型
    // qdii QDII
    // lof  LOF
    // fof  FOF
    for (var index = 1; index < 9; index++) {
        tempTypes.push(types[index]);
        xhr = new XMLHttpRequest();
        xhr.open("GET", "http://fund.eastmoney.com/data/rankhandler.aspx?op=ph&dt=kf&ft=hh&rs=&gs=0&sc=" + fts[index] + "&st=desc&sd=&ed=&qdii=|&tabSubtype=,,,,,&pi=1&pn=10000&dx=1&v=" + Math.random(), false);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                var result = xhr.responseText;
                if (result) {
                    var allRecords = result.slice(result.indexOf("],allRecords:") + 13, result.indexOf(",pageIndex:"));
                    if (types[index] == "oneWeek" || types[index] == "oneMonth" || types[index] == "threeMonth" || types[index] == "sixMonth") {
                        allRecords = parseInt(allRecords / 3);
                    } else {
                        allRecords = parseInt(allRecords / 4);
                    }
                    var result_match = result.slice(result.indexOf("{datas:") + 7, result.indexOf(",allRecords:"));
                    result_match = JSON.parse(result_match);
                    var items = [];
                    var tempItems = [];
                    for (var i = 0; i < allRecords; i++) {
                        var result = result_match[i].split(",");
                        items.push({
                            "code": result[0],
                            "name": result[1]
                        });
                        tempItems.push(result[0]);
                    }
                    tempSortRecords[types[index]] = tempItems;
                    detailSortRecords[types[index]] = items;
                }
            }
        }
        xhr.send();
    }

    var jiaoji = tempSortRecords["sixMonth"];
    tempTypes.reduce(function(pre, cur, index, array) {
        jiaoji = jiaoji.filter(function(n) {
            return tempSortRecords[cur].indexOf(n) != -1;
        });
        return jiaoji;
    }, tempSortRecords["sixMonth"]);

    var bestSortRecords = [];
    var sampleCodes = [];
    var oneWeeks = detailSortRecords["sixMonth"];
    for (var i in oneWeeks) {
        var oneWeek = oneWeeks[i];
        for (var j in jiaoji) {
            if (oneWeek["code"] == jiaoji[j]) {
                bestSortRecords.push(oneWeek);
                sampleCodes.push(oneWeek["code"]);
            }
        }
    }

    var sampleResults = sample(sampleCodes, 120);

    for (var i in sampleCodes) {
        for (var j in bestSortRecords) {
            if (sampleCodes[i] == bestSortRecords[j]["code"]) {
                bestSortRecords[j]["average"] = sampleResults[sampleCodes[i]]["average"];
                bestSortRecords[j]["variance"] = sampleResults[sampleCodes[i]]["variance"];
                bestSortRecords[j]["standard"] = sampleResults[sampleCodes[i]]["standard"];
            }
        }
    }

    return bestSortRecords;
}

var sample = function(codes, days) {
    var today = moment().format("YYYY-MM-DD");
    var beforeDay = getDay(-1 * days);
    var sampleDatas = {};
    var valuesDatas = {};
    for (var index = 0; index < codes.length; index++) {
        xhr = new XMLHttpRequest();
        xhr.open("GET", "http://fund.eastmoney.com/f10/F10DataApi.aspx?type=lsjz&code=" + codes[index] + "&page=1&per=49&sdate=" + beforeDay + "&edate=" + today + "&rt=" + Math.random(), false);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                var result = xhr.responseText;
                if (result) {
                    var jsonObj = parseJsonObject(result);
                    sampleDatas[codes[index]] = getSampleDatas(codes[index], jsonObj["pages"], beforeDay, today);
                }
            }
        }
        xhr.send();
    }

    for (var index in sampleDatas) {
        var allRecords = sampleDatas[index];
        var total = 0;
        for (var i = 0; i < allRecords.length; i++) {
            total += allRecords[i] * 1;
        }
        var average = (total / allRecords.length).toFixed(2);

        var totalVariance = 0;
        for (var i = 0; i < allRecords.length; i++) {
            totalVariance += Math.pow((allRecords[i] * 1 - average), 2);
        }

        var variance = totalVariance / (allRecords.length - 1);

        valuesDatas[index] = {
            "average": average, //平均（均值）
            "variance": variance.toFixed(6), //方差
            "standard": Math.sqrt(variance).toFixed(6), //标准差
        };
    }
    return valuesDatas;
}

var getSampleDatas = function(code, pages, sDate, eDate) {
    var records = [];
    for (var page = 1; page <= pages; page++) {
        xhr = new XMLHttpRequest();
        xhr.open("GET", "http://fund.eastmoney.com/f10/F10DataApi.aspx?type=lsjz&code=" + code + "&page=" + page + "&per=49&sdate=" + sDate + "&edate=" + eDate + "&rt=" + Math.random(), false);
        xhr.onreadystatechange = function() {
            if (xhr.readyState == 4) {
                var result = xhr.responseText;
                if (result) {
                    try {
                        var result_match = result.match(/<tbody.*>.*?<\/tbody>/);
                        if (result_match) {
                            var $trs = $(result_match[0]).find("tr");
                            $.each($trs, function(index, item) {
                                records.push($(this).find(".tor.bold").first().html());
                            });
                        }
                    } catch (err) {}
                }
            }
        }
        xhr.send();
    }
    return records;
}

/**
 * 获取所有基金的代码code
 */
var getAllfundCodes = function() {
    var codes = [];
    xhr = new XMLHttpRequest();
    xhr.open("GET", "http://fund.eastmoney.com/allfund.html", false);
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            var result = xhr.responseText;
            if (result) {
                var $ul_lis = $(result).find("#code_content .num_box ul.num_right li");
                $.each($ul_lis, function(index, item) {
                    var code = $(this).find("a").first().text().replace(/[^0-9]/ig, "");
                    if (code && code.length > 5) {
                        codes.push(code.substr(0, 6) + "");
                    }
                });
            }
        }
    }
    xhr.send();
    return codes;
}

var getAllfund_tsdata = function() {
    var tsdata = [],
        tmp_tsdata = {};
    var codes = getAllfundCodes();
    $.each(codes, function(index, key) {
        if (isNumeric(key)) {
            var old_tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
            if (!isBlank(old_tsdata_json[key])) {
                return true;
            }
            (function(key) {
                xhr[key] = new XMLHttpRequest();
                xhr[key].open("GET", "http://fundf10.eastmoney.com/tsdata_" + key + ".html", true);
                xhr[key].onreadystatechange = function() {
                    if (xhr[key].readyState == 4) {
                        var result = xhr[key].responseText;
                        if (result) {
                            var $tbody = $(result).find("div.boxitem.w790 table.fxtb tbody");
                            var $bz_td = $tbody.find("tr").eq(1).find("td");
                            var $xp_td = $tbody.find("tr").eq(2).find("td");

                            var old_tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
                            old_tsdata_json[key] = {
                                "code": key,
                                "bz_one": $bz_td.eq(1).text() == "--" ? "0%" : $bz_td.eq(1).text(),
                                "bz_two": $bz_td.eq(2).text() == "--" ? "0%" : $bz_td.eq(2).text(),
                                "bz_three": $bz_td.eq(3).text() == "--" ? "0%" : $bz_td.eq(3).text(),
                                "xp_one": $xp_td.eq(1).text() == "--" ? "0" : $xp_td.eq(1).text(),
                                "xp_two": $xp_td.eq(2).text() == "--" ? "0" : $xp_td.eq(2).text(),
                                "xp_three": $xp_td.eq(3).text() == "--" ? "0" : $xp_td.eq(3).text(),
                            };
                            localStorage.setItem("tsdata", JSON.stringify(old_tsdata_json));
                        }
                    }
                }
                xhr[key].send();
            })(key);
        }
    });

    return;

    setTimeout(function() {
        var tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
        $.each(tsdata_json, function(index, item) {
            tsdata.push(item);
        });
        var bz_one_order = tsdata.sort(function(a, b) {
            var tmp_a_bz_one = a.bz_one.replace("%", "");
            var tmp_b_bz_one = b.bz_one.replace("%", "");
            return (tmp_b_bz_one * 1 - tmp_a_bz_one * 1);
        });

        tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
        tsdata = [];
        $.each(tsdata_json, function(index, item) {
            tsdata.push(item);
        });
        var bz_two_order = tsdata.sort(function(a, b) {
            var tmp_a_bz_two = a.bz_two.replace("%", "");
            var tmp_b_bz_two = b.bz_two.replace("%", "");
            return (tmp_b_bz_two * 1 - tmp_a_bz_two * 1);
        });

        tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
        tsdata = [];
        $.each(tsdata_json, function(index, item) {
            tsdata.push(item);
        });
        var bz_three_order = tsdata.sort(function(a, b) {
            var tmp_a_bz_three = a.bz_three.replace("%", "");
            var tmp_b_bz_three = b.bz_three.replace("%", "");
            return (tmp_b_bz_three * 1 - tmp_a_bz_three * 1);
        });

        tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
        tsdata = [];
        $.each(tsdata_json, function(index, item) {
            tsdata.push(item);
        });
        var xp_one_order = tsdata.sort(function(a, b) {
            return a.xp_one - b.xp_one;
        });

        tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
        tsdata = [];
        $.each(tsdata_json, function(index, item) {
            tsdata.push(item);
        });
        var xp_two_order = tsdata.sort(function(a, b) {
            return a.xp_two - b.xp_two;
        });

        tsdata_json = JSON.parse(isBlank(localStorage.getItem("tsdata")) ? "{}" : localStorage.getItem("tsdata"));
        tsdata = [];
        $.each(tsdata_json, function(index, item) {
            tsdata.push(item);
        });
        var xp_three_order = tsdata.sort(function(a, b) {
            return a.xp_three - b.xp_three;
        });
    }, 300000);
}

var getDay = function(day) {
    if (!day) {
        day = 0;
    }
    var time = new Date();
    time.setDate(time.getDate() + day); //获取Day天后的日期 
    var y = time.getFullYear();
    var m = time.getMonth() + 1; //获取当前月份的日期 
    var d = time.getDate();
    return y + "-" + m + "-" + d;
}

var parseJsonObject = function(data) {
    const start = data.indexOf("{");
    const end = data.indexOf("}") + 1;
    const jsonStr = data.slice(start, end);
    const jsonObj = eval("(" + jsonStr + ")");
    return jsonObj
}